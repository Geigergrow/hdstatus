package com.example.hdstatus

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object VideoCompressor {

    /**
     * Re-encode video ke H.264/AAC dengan bitrate tertentu.
     * Harus dipanggil dari main thread (Transformer butuh Looper).
     */
    suspend fun compress(
        context: Context,
        input: Uri,
        output: File,
        videoBitrate: Int = 4_000_000, // 4 Mbps, atur sesuai kebutuhan
    ): File = suspendCancellableCoroutine { cont ->
        if (output.exists()) output.delete()

        val encoderFactory = DefaultEncoderFactory.Builder(context)
            .setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder().setBitrate(videoBitrate).build()
            )
            .build()

        val transformer = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoderFactory)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    if (cont.isActive) cont.resume(output)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException,
                ) {
                    if (cont.isActive) cont.resumeWithException(exportException)
                }
            })
            .build()

        val item = EditedMediaItem.Builder(MediaItem.fromUri(input)).build()
        transformer.start(item, output.absolutePath)
        cont.invokeOnCancellation { transformer.cancel() }
    }
}
